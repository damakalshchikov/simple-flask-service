"""flask-service-metrics - сбор и экспорт метрик производительности Flask-приложений."""

from flask_service_metrics.decorators import measure
from flask_service_metrics.extension import FlaskMetrics
from flask_service_metrics.metrics import Counter, Gauge, Histogram, MetricSnapshot, Sample
from flask_service_metrics.registry import MetricsRegistry, default_registry

__version__ = "0.1.1"

__all__ = [
    "Counter",
    "FlaskMetrics",
    "Gauge",
    "Histogram",
    "MetricSnapshot",
    "MetricsRegistry",
    "Sample",
    "default_registry",
    "measure",
    "__version__",
]
