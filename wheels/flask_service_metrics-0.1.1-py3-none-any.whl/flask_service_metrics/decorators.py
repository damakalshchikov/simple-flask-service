"""Декоратор @measure - декларативное измерение произвольных функций и методов."""

from __future__ import annotations

import functools
import time
from collections.abc import Callable, Sequence
from typing import Any, overload

from flask_service_metrics.metrics import Histogram
from flask_service_metrics.registry import MetricsRegistry, default_registry

_DURATION_NAME = "function_duration_seconds"
_CALLS_NAME = "function_calls_total"


@overload
def measure[**P, R](func: Callable[P, R]) -> Callable[P, R]: ...


@overload
def measure[**P, R](
    func: None = None,
    *,
    name: str | None = None,
    registry: MetricsRegistry | None = None,
    buckets: Sequence[float] | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]: ...


def measure(
    func: Callable[..., Any] | None = None,
    *,
    name: str | None = None,
    registry: MetricsRegistry | None = None,
    buckets: Sequence[float] | None = None,
) -> Any:
    """Измеряет время выполнения, число вызовов и исключения функции.

    Поддерживает обе формы: @measure и @measure(name=...). Метрики общие для
    всех декорированных функций, конкретная функция - лейбл ``function``.
    Child-объекты метрик резолвятся один раз при декорировании, горячий путь -
    perf_counter + observe + inc.
    """

    def decorator[**P, R](fn: Callable[P, R]) -> Callable[P, R]:
        reg = registry if registry is not None else default_registry
        function_name = name if name is not None else f"{fn.__module__}.{fn.__qualname__}"
        duration = reg.histogram(
            _DURATION_NAME,
            "Время выполнения декорированных функций, секунды",
            labelnames=("function",),
            buckets=buckets if buckets is not None else Histogram.DEFAULT_BUCKETS,
        ).labels(function=function_name)
        calls = reg.counter(
            _CALLS_NAME,
            "Число вызовов декорированных функций",
            labelnames=("function", "status"),
        )
        calls_ok = calls.labels(function=function_name, status="ok")
        calls_error = calls.labels(function=function_name, status="error")

        @functools.wraps(fn)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            start = time.perf_counter()
            try:
                result = fn(*args, **kwargs)
            except BaseException:
                calls_error.inc()
                raise
            else:
                calls_ok.inc()
                return result
            finally:
                duration.observe(time.perf_counter() - start)

        return wrapper

    if func is not None:
        return decorator(func)
    return decorator
