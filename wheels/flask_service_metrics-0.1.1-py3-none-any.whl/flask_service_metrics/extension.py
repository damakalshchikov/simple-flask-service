"""Flask-расширение FlaskMetrics: автоматическое подключение всех групп метрик."""

from __future__ import annotations

import atexit
import threading
import time
from typing import TYPE_CHECKING

from flask import Flask, Response, g, request

from flask_service_metrics import prometheus
from flask_service_metrics.metrics import Histogram
from flask_service_metrics.process import ProcessCollector
from flask_service_metrics.registry import MetricsRegistry, default_registry

if TYPE_CHECKING:
    from flask_service_metrics.logexport import LogFileExporter

_EXTENSION_KEY = "flask_service_metrics"


class FlaskMetrics:
    """Подключает сбор HTTP-, SQL- и процессных метрик к Flask-приложению.

    Использование - стандартный паттерн расширений::

        metrics = FlaskMetrics()

        def create_app():
            app = Flask(__name__)
            metrics.init_app(app)
            return app
    """

    def __init__(self, app: Flask | None = None, registry: MetricsRegistry | None = None) -> None:
        self.registry = registry if registry is not None else default_registry
        self._exporter: LogFileExporter | None = None
        self._exporter_started = False
        self._exporter_lock = threading.Lock()
        if app is not None:
            self.init_app(app)

    def init_app(self, app: Flask) -> None:
        if _EXTENSION_KEY in app.extensions:
            raise RuntimeError("FlaskMetrics уже инициализирован для этого приложения")
        app.extensions[_EXTENSION_KEY] = self

        namespace = app.config.setdefault("METRICS_NAMESPACE", "")
        endpoint_path = app.config.setdefault("METRICS_ENDPOINT", "/metrics")
        exclude_paths = set(app.config.setdefault("METRICS_EXCLUDE_PATHS", ["/metrics"]))
        http_buckets = app.config.setdefault("METRICS_HTTP_BUCKETS", Histogram.DEFAULT_BUCKETS)
        prefix = f"{namespace}_" if namespace else ""

        if app.config.setdefault("METRICS_ENABLE_HTTP", True):
            self._init_http(app, prefix, exclude_paths, http_buckets)

        if app.config.setdefault("METRICS_ENABLE_PROCESS", True):
            self.registry.register_collector(ProcessCollector().collect)

        if app.config.setdefault("METRICS_ENABLE_SQLALCHEMY", True):
            try:
                from flask_service_metrics.sqla import instrument_sqlalchemy
            except ImportError:
                pass  # SQLAlchemy не установлена - группа тихо отключается
            else:
                instrument_sqlalchemy(self.registry)

        if endpoint_path:
            app.add_url_rule(endpoint_path, _EXTENSION_KEY, self._metrics_view)

        log_file = app.config.setdefault("METRICS_LOG_FILE", None)
        if log_file:
            self._init_log_exporter(app, log_file)

    def _init_http(
        self,
        app: Flask,
        prefix: str,
        exclude_paths: set[str],
        buckets: tuple[float, ...],
    ) -> None:
        duration = self.registry.histogram(
            f"{prefix}http_request_duration_seconds",
            "Время обработки HTTP-запросов, секунды",
            labelnames=("method", "endpoint"),
            buckets=buckets,
        )
        requests_total = self.registry.counter(
            f"{prefix}http_requests_total",
            "Число обработанных HTTP-запросов",
            labelnames=("method", "endpoint", "status"),
        )
        exceptions_total = self.registry.counter(
            f"{prefix}http_request_exceptions_total",
            "Число HTTP-запросов, завершившихся необработанным исключением",
            labelnames=("method", "endpoint"),
        )

        def before_request() -> None:
            if request.path in exclude_paths:
                return
            g._metrics_start = time.perf_counter()

        def after_request(response: Response) -> Response:
            start = getattr(g, "_metrics_start", None)
            if start is not None:
                endpoint = _endpoint_label()
                duration.labels(method=request.method, endpoint=endpoint).observe(
                    time.perf_counter() - start
                )
                requests_total.labels(
                    method=request.method,
                    endpoint=endpoint,
                    status=str(response.status_code),
                ).inc()
            return response

        def teardown_request(exc: BaseException | None) -> None:
            if exc is not None and getattr(g, "_metrics_start", None) is not None:
                exceptions_total.labels(
                    method=request.method, endpoint=_endpoint_label()
                ).inc()

        app.before_request(before_request)
        app.after_request(after_request)
        app.teardown_request(teardown_request)

    def _metrics_view(self) -> Response:
        return Response(
            prometheus.render(self.registry.collect()), mimetype=prometheus.CONTENT_TYPE
        )

    def _init_log_exporter(self, app: Flask, log_file: str) -> None:
        from flask_service_metrics.logexport import LogFileExporter

        self._exporter = LogFileExporter(
            self.registry,
            log_file,
            interval=app.config.setdefault("METRICS_LOG_INTERVAL", 60.0),
            stdout_summary=app.config.setdefault("METRICS_STDOUT_SUMMARY", False),
        )

        # Старт лениво на первом запросе, а не в init_app: поток, созданный до
        # fork'а gunicorn (--preload), не переживёт fork.
        def start_exporter() -> None:
            if self._exporter_started:
                return
            with self._exporter_lock:
                if not self._exporter_started:
                    assert self._exporter is not None
                    self._exporter.start()
                    atexit.register(self._exporter.stop)
                    self._exporter_started = True

        app.before_request(start_exporter)


def _endpoint_label() -> str:
    """Шаблон пути (/tasks/<uuid:task_id>) - ограниченная кардинальность лейбла."""
    rule = request.url_rule
    return rule.rule if rule is not None else "unmatched"
