"""Периодический экспорт агрегированных метрик в лог-файл (JSON Lines).

Фоновый daemon-поток раз в interval секунд сбрасывает снапшоты реестра одной
JSON-строкой в файл (append). Опционально печатает краткую сводку в stdout.
"""

from __future__ import annotations

import json
import logging
import threading
from datetime import UTC, datetime
from pathlib import Path

from flask_service_metrics.metrics import MetricSnapshot
from flask_service_metrics.registry import MetricsRegistry

logger = logging.getLogger(__name__)


def snapshots_to_dict(snapshots: list[MetricSnapshot]) -> list[dict[str, object]]:
    return [
        {
            "name": snapshot.name,
            "type": snapshot.type,
            "samples": [
                {"suffix": sample.suffix, "labels": sample.labels, "value": sample.value}
                for sample in snapshot.samples
            ],
        }
        for snapshot in snapshots
    ]


class LogFileExporter:
    def __init__(
        self,
        registry: MetricsRegistry,
        path: str | Path,
        interval: float = 60.0,
        stdout_summary: bool = False,
    ) -> None:
        self.registry = registry
        self.path = Path(path)
        self.interval = interval
        self.stdout_summary = stdout_summary
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._run, name="flask-service-metrics-logexport", daemon=True
        )
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        if self._thread is None:
            return
        self._stop.set()
        self._thread.join(timeout)
        self._thread = None
        self.dump_once()  # финальный сброс при завершении worker'а

    def _run(self) -> None:
        # Event.wait даёт и интервал, и мгновенное graceful-завершение.
        while not self._stop.wait(self.interval):
            self.dump_once()

    def dump_once(self) -> None:
        """Один сброс метрик; ошибки не должны ронять приложение."""
        try:
            snapshots = self.registry.collect()
            record = {
                "timestamp": datetime.now(UTC).isoformat(timespec="seconds"),
                "metrics": snapshots_to_dict(snapshots),
            }
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
            if self.stdout_summary:
                print(_summary(snapshots))
        except Exception:
            logger.exception("не удалось записать метрики в %s", self.path)


def _summary(snapshots: list[MetricSnapshot]) -> str:
    """Компактная человекочитаемая сводка: имя метрики -> суммарное значение."""
    lines = ["[flask-service-metrics] сводка:"]
    for snapshot in snapshots:
        if snapshot.type == "histogram":
            count = sum(s.value for s in snapshot.samples if s.suffix == "_count")
            total = sum(s.value for s in snapshot.samples if s.suffix == "_sum")
            mean = total / count if count else 0.0
            lines.append(f"  {snapshot.name}: count={count:.0f} mean={mean:.6f}s")
        else:
            total = sum(s.value for s in snapshot.samples)
            lines.append(f"  {snapshot.name}: {total:g}")
    return "\n".join(lines)
