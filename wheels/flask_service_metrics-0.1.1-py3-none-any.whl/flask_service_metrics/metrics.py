"""Примитивы метрик: Counter, Gauge, Histogram.

Хранение отделено от рендеринга: метрики накапливают значения, а collect()
возвращает иммутабельные снапшоты, которые потребляют экспортёры
(Prometheus-рендер и лог-экспортёр).
"""

from __future__ import annotations

import re
import threading
from bisect import bisect_left
from collections.abc import Sequence
from dataclasses import dataclass

_NAME_RE = re.compile(r"[a-zA-Z_:][a-zA-Z0-9_:]*")
_LABEL_RE = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")

type LabelValues = tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Sample:
    """Одно значение метрики: суффикс имени, лейблы и число."""

    suffix: str  # "" | "_bucket" | "_sum" | "_count"
    labels: dict[str, str]
    value: float


@dataclass(frozen=True, slots=True)
class MetricSnapshot:
    """Иммутабельный снимок метрики на момент collect()."""

    name: str
    type: str  # "counter" | "gauge" | "histogram"
    help: str
    samples: tuple[Sample, ...]


def _validate_name(name: str) -> None:
    if not _NAME_RE.fullmatch(name):
        raise ValueError(f"недопустимое имя метрики: {name!r}")


def _validate_labelnames(labelnames: Sequence[str]) -> None:
    for label in labelnames:
        if not _LABEL_RE.fullmatch(label) or label.startswith("__"):
            raise ValueError(f"недопустимое имя лейбла: {label!r}")


class _Metric:
    """Базовый класс: паттерн label-child.

    labels(**values) возвращает дочерний объект для конкретной комбинации
    лейблов (get-or-create). Безлейбловая метрика - это child с ключом ().
    Один Lock на метрику защищает и создание child, и мутацию значений.
    """

    type: str = ""

    def __init__(self, name: str, help: str, labelnames: Sequence[str] = ()) -> None:
        _validate_name(name)
        _validate_labelnames(labelnames)
        self.name = name
        self.help = help
        self.labelnames = tuple(labelnames)
        self._lock = threading.Lock()
        self._children: dict[LabelValues, _Child] = {}
        if not self.labelnames:
            self._children[()] = self._make_child()

    def _make_child(self) -> _Child:
        raise NotImplementedError

    def labels(self, **labelvalues: str) -> _Child:
        if set(labelvalues) != set(self.labelnames):
            raise ValueError(
                f"метрика {self.name!r} ожидает лейблы {self.labelnames}, "
                f"получены {tuple(labelvalues)}"
            )
        key = tuple(str(labelvalues[name]) for name in self.labelnames)
        with self._lock:
            child = self._children.get(key)
            if child is None:
                child = self._make_child()
                self._children[key] = child
            return child

    def _unlabelled(self) -> _Child:
        if self.labelnames:
            raise ValueError(f"метрика {self.name!r} имеет лейблы - используйте .labels()")
        return self._children[()]

    def collect(self) -> MetricSnapshot:
        samples: list[Sample] = []
        with self._lock:
            for key, child in self._children.items():
                labels = dict(zip(self.labelnames, key, strict=True))
                samples.extend(child.samples(labels))
        return MetricSnapshot(
            name=self.name, type=self.type, help=self.help, samples=tuple(samples)
        )


class _Child:
    def samples(self, labels: dict[str, str]) -> list[Sample]:
        raise NotImplementedError


class _CounterChild(_Child):
    __slots__ = ("_lock", "_value")

    def __init__(self, lock: threading.Lock) -> None:
        self._lock = lock
        self._value = 0.0

    def inc(self, amount: float = 1.0) -> None:
        if amount < 0:
            raise ValueError("счётчик нельзя уменьшать")
        with self._lock:
            self._value += amount

    def samples(self, labels: dict[str, str]) -> list[Sample]:
        return [Sample("", labels, self._value)]


class Counter(_Metric):
    """Монотонно растущий счётчик. Имя обязано оканчиваться на _total."""

    type = "counter"

    def __init__(self, name: str, help: str, labelnames: Sequence[str] = ()) -> None:
        if not name.endswith("_total"):
            raise ValueError(f"имя счётчика должно оканчиваться на '_total': {name!r}")
        super().__init__(name, help, labelnames)

    def _make_child(self) -> _CounterChild:
        return _CounterChild(self._lock)

    def labels(self, **labelvalues: str) -> _CounterChild:
        child = super().labels(**labelvalues)
        assert isinstance(child, _CounterChild)
        return child

    def inc(self, amount: float = 1.0) -> None:
        child = self._unlabelled()
        assert isinstance(child, _CounterChild)
        child.inc(amount)


class _GaugeChild(_Child):
    __slots__ = ("_lock", "_value")

    def __init__(self, lock: threading.Lock) -> None:
        self._lock = lock
        self._value = 0.0

    def set(self, value: float) -> None:
        with self._lock:
            self._value = value

    def inc(self, amount: float = 1.0) -> None:
        with self._lock:
            self._value += amount

    def dec(self, amount: float = 1.0) -> None:
        with self._lock:
            self._value -= amount

    def samples(self, labels: dict[str, str]) -> list[Sample]:
        return [Sample("", labels, self._value)]


class Gauge(_Metric):
    """Значение, которое может расти и убывать."""

    type = "gauge"

    def _make_child(self) -> _GaugeChild:
        return _GaugeChild(self._lock)

    def labels(self, **labelvalues: str) -> _GaugeChild:
        child = super().labels(**labelvalues)
        assert isinstance(child, _GaugeChild)
        return child

    def set(self, value: float) -> None:
        child = self._unlabelled()
        assert isinstance(child, _GaugeChild)
        child.set(value)

    def inc(self, amount: float = 1.0) -> None:
        child = self._unlabelled()
        assert isinstance(child, _GaugeChild)
        child.inc(amount)

    def dec(self, amount: float = 1.0) -> None:
        child = self._unlabelled()
        assert isinstance(child, _GaugeChild)
        child.dec(amount)


class _HistogramChild(_Child):
    __slots__ = ("_lock", "_bounds", "_buckets", "_sum", "_count")

    def __init__(self, lock: threading.Lock, bounds: tuple[float, ...]) -> None:
        self._lock = lock
        self._bounds = bounds
        # Некумулятивные бакеты; последний слот - неявный +Inf.
        self._buckets = [0] * (len(bounds) + 1)
        self._sum = 0.0
        self._count = 0

    def observe(self, value: float) -> None:
        idx = bisect_left(self._bounds, value)
        with self._lock:
            self._buckets[idx] += 1
            self._sum += value
            self._count += 1

    def samples(self, labels: dict[str, str]) -> list[Sample]:
        result: list[Sample] = []
        cumulative = 0
        for bound, count in zip(self._bounds, self._buckets, strict=False):
            cumulative += count
            result.append(Sample("_bucket", {**labels, "le": _format_bound(bound)}, cumulative))
        result.append(Sample("_bucket", {**labels, "le": "+Inf"}, self._count))
        result.append(Sample("_sum", labels, self._sum))
        result.append(Sample("_count", labels, self._count))
        return result


def _format_bound(bound: float) -> str:
    """Границы бакетов без лишних нулей: 1.0 -> "1.0", 0.005 -> "0.005"."""
    return repr(bound)


class Histogram(_Metric):
    """Распределение значений по бакетам + сумма и количество."""

    type = "histogram"

    DEFAULT_BUCKETS: tuple[float, ...] = (
        0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0,
    )

    def __init__(
        self,
        name: str,
        help: str,
        labelnames: Sequence[str] = (),
        buckets: Sequence[float] = DEFAULT_BUCKETS,
    ) -> None:
        if not buckets:
            raise ValueError("нужен хотя бы один бакет")
        bounds = tuple(float(b) for b in buckets)
        if list(bounds) != sorted(bounds):
            raise ValueError("границы бакетов должны быть отсортированы по возрастанию")
        self.buckets = bounds
        super().__init__(name, help, labelnames)

    def _make_child(self) -> _HistogramChild:
        return _HistogramChild(self._lock, self.buckets)

    def labels(self, **labelvalues: str) -> _HistogramChild:
        child = super().labels(**labelvalues)
        assert isinstance(child, _HistogramChild)
        return child

    def observe(self, value: float) -> None:
        child = self._unlabelled()
        assert isinstance(child, _HistogramChild)
        child.observe(value)
