"""Метрики процесса: CPU, память, потоки, GC - значимые для Kubernetes/Deckhouse.

Только stdlib: в Linux-контейнерах всё доступно через /proc/self/*, на macOS
(машина разработчика) часть метрик берётся из resource.getrusage, а Linux-only
сэмплы просто опускаются.
"""

from __future__ import annotations

import gc
import os
import sys
import threading
import time

from flask_service_metrics.metrics import MetricSnapshot, Sample

_PAGE_SIZE = os.sysconf("SC_PAGE_SIZE") if hasattr(os, "sysconf") else 4096
_CLK_TCK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100


class ProcessCollector:
    """Сэмплирует показатели процесса в момент вызова collect() (pull-time)."""

    def __init__(self) -> None:
        self._start_time = time.time() - _process_uptime()

    def collect(self) -> list[MetricSnapshot]:
        snapshots = [
            _gauge("process_start_time_seconds", "Unix-время старта процесса", self._start_time),
            _gauge("process_threads", "Число активных потоков", threading.active_count()),
        ]

        cpu = _cpu_seconds()
        if cpu is not None:
            snapshots.append(
                MetricSnapshot(
                    name="process_cpu_seconds_total",
                    type="counter",
                    help="Суммарное CPU-время процесса (user + system), секунды",
                    samples=(Sample("", {}, cpu),),
                )
            )

        memory = _memory_bytes()
        if memory is not None:
            rss, vsize = memory
            snapshots.append(_gauge("process_resident_memory_bytes", "Резидентная память", rss))
            if vsize is not None:
                snapshots.append(
                    _gauge("process_virtual_memory_bytes", "Виртуальная память", vsize)
                )

        fds = _open_fds()
        if fds is not None:
            snapshots.append(_gauge("process_open_fds", "Число открытых дескрипторов", fds))

        snapshots.extend(_gc_snapshots())
        return snapshots


def _gauge(name: str, help: str, value: float) -> MetricSnapshot:
    return MetricSnapshot(name=name, type="gauge", help=help, samples=(Sample("", {}, value),))


def _read_proc_stat() -> list[str] | None:
    try:
        with open("/proc/self/stat") as f:
            stat = f.read()
    except OSError:
        return None
    # Имя процесса в скобках может содержать пробелы - режем по закрывающей скобке.
    return stat.rpartition(")")[2].split()


def _cpu_seconds() -> float | None:
    fields = _read_proc_stat()
    if fields is not None:
        # После ")" поля идут с индекса 0 = state; utime/stime - поля 14/15 в stat,
        # то есть индексы 11 и 12 здесь.
        return (int(fields[11]) + int(fields[12])) / _CLK_TCK
    try:
        import resource

        usage = resource.getrusage(resource.RUSAGE_SELF)
        return usage.ru_utime + usage.ru_stime
    except (ImportError, OSError):
        return None


def _memory_bytes() -> tuple[float, float | None] | None:
    fields = _read_proc_stat()
    if fields is not None:
        vsize = float(fields[20])
        rss = float(fields[21]) * _PAGE_SIZE
        return rss, vsize
    try:
        import resource

        maxrss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # macOS отдаёт ru_maxrss в байтах, Linux - в КиБ.
        rss = float(maxrss) if sys.platform == "darwin" else float(maxrss) * 1024
        return rss, None
    except (ImportError, OSError):
        return None


def _open_fds() -> int | None:
    try:
        return len(os.listdir("/proc/self/fd"))
    except OSError:
        return None


def _process_uptime() -> float:
    fields = _read_proc_stat()
    if fields is None:
        return 0.0
    try:
        with open("/proc/uptime") as f:
            system_uptime = float(f.read().split()[0])
    except OSError:
        return 0.0
    starttime_ticks = int(fields[19])
    return system_uptime - starttime_ticks / _CLK_TCK


def _gc_snapshots() -> list[MetricSnapshot]:
    stats = gc.get_stats()
    collections = tuple(
        Sample("", {"generation": str(gen)}, stat["collections"])
        for gen, stat in enumerate(stats)
    )
    collected = tuple(
        Sample("", {"generation": str(gen)}, stat["collected"])
        for gen, stat in enumerate(stats)
    )
    return [
        MetricSnapshot(
            name="python_gc_collections_total",
            type="counter",
            help="Число сборок мусора по поколениям",
            samples=collections,
        ),
        MetricSnapshot(
            name="python_gc_objects_collected_total",
            type="counter",
            help="Число собранных объектов по поколениям",
            samples=collected,
        ),
    ]
