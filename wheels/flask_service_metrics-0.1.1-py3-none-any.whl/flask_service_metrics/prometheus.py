"""Рендер снапшотов в текстовый формат экспозиции Prometheus 0.0.4."""

from __future__ import annotations

import math
from collections.abc import Iterable

from flask_service_metrics.metrics import MetricSnapshot

CONTENT_TYPE = "text/plain; version=0.0.4; charset=utf-8"


def _escape_help(text: str) -> str:
    return text.replace("\\", "\\\\").replace("\n", "\\n")


def _escape_label_value(text: str) -> str:
    return text.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _format_value(value: float) -> str:
    if math.isnan(value):
        return "NaN"
    if math.isinf(value):
        return "+Inf" if value > 0 else "-Inf"
    if value == int(value):
        return str(int(value))
    return repr(value)


def render(snapshots: Iterable[MetricSnapshot]) -> str:
    lines: list[str] = []
    for snapshot in snapshots:
        lines.append(f"# HELP {snapshot.name} {_escape_help(snapshot.help)}")
        lines.append(f"# TYPE {snapshot.name} {snapshot.type}")
        for sample in snapshot.samples:
            name = snapshot.name + sample.suffix
            if sample.labels:
                labels = ",".join(
                    f'{key}="{_escape_label_value(value)}"'
                    for key, value in sample.labels.items()
                )
                lines.append(f"{name}{{{labels}}} {_format_value(sample.value)}")
            else:
                lines.append(f"{name} {_format_value(sample.value)}")
    return "\n".join(lines) + "\n"
