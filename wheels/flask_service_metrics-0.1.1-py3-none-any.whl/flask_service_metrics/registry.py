"""Реестр метрик: единая точка регистрации и сбора снапшотов."""

from __future__ import annotations

import threading
from collections.abc import Callable, Sequence

from flask_service_metrics.metrics import Counter, Gauge, Histogram, MetricSnapshot, _Metric

type Collector = Callable[[], list[MetricSnapshot]]


class MetricsRegistry:
    """Хранит метрики по имени и коллекторы, сэмплируемые в момент collect().

    Фабричные методы работают в режиме get-or-create: повторный запрос метрики
    с тем же именем и параметрами возвращает существующий объект, а конфликт
    типа или лейблов - ошибка. Это делает декораторы безопасными при повторных
    импортах и позволяет расширению и декораторам разделять метрики.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._metrics: dict[str, _Metric] = {}
        self._collectors: list[Collector] = []

    def counter(self, name: str, help: str, labelnames: Sequence[str] = ()) -> Counter:
        return self._get_or_create(Counter, name, help, labelnames)

    def gauge(self, name: str, help: str, labelnames: Sequence[str] = ()) -> Gauge:
        return self._get_or_create(Gauge, name, help, labelnames)

    def histogram(
        self,
        name: str,
        help: str,
        labelnames: Sequence[str] = (),
        buckets: Sequence[float] = Histogram.DEFAULT_BUCKETS,
    ) -> Histogram:
        metric = self._get_or_create(Histogram, name, help, labelnames, buckets=buckets)
        if metric.buckets != tuple(float(b) for b in buckets):
            raise ValueError(f"метрика {name!r} уже зарегистрирована с другими бакетами")
        return metric

    def _get_or_create[M: _Metric](
        self,
        cls: type[M],
        name: str,
        help: str,
        labelnames: Sequence[str],
        **kwargs: object,
    ) -> M:
        with self._lock:
            existing = self._metrics.get(name)
            if existing is not None:
                if type(existing) is not cls:
                    raise ValueError(
                        f"метрика {name!r} уже зарегистрирована с типом {existing.type!r}"
                    )
                if existing.labelnames != tuple(labelnames):
                    raise ValueError(
                        f"метрика {name!r} уже зарегистрирована с лейблами {existing.labelnames}"
                    )
                return existing
            metric = cls(name, help, labelnames, **kwargs)
            self._metrics[name] = metric
            return metric

    def register_collector(self, collector: Collector) -> None:
        """Коллектор вызывается при каждом collect() - pull-time сэмплинг."""
        with self._lock:
            if collector not in self._collectors:
                self._collectors.append(collector)

    def collect(self) -> list[MetricSnapshot]:
        with self._lock:
            metrics = list(self._metrics.values())
            collectors = list(self._collectors)
        snapshots = [metric.collect() for metric in metrics]
        for collector in collectors:
            snapshots.extend(collector())
        return snapshots

    def clear(self) -> None:
        """Полный сброс - для изоляции тестов."""
        with self._lock:
            self._metrics.clear()
            self._collectors.clear()


default_registry = MetricsRegistry()
