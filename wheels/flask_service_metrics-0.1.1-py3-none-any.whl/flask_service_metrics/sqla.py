"""Опциональная инструментация SQLAlchemy: время и количество SQL-запросов.

Модуль импортирует sqlalchemy на верхнем уровне - подключайте его только при
установленном extras ``flask-service-metrics[sqlalchemy]``. FlaskMetrics
импортирует модуль лениво под try/except ImportError.
"""

from __future__ import annotations

import time
import weakref
from collections.abc import Sequence
from typing import Any

from sqlalchemy import event
from sqlalchemy.engine import Connection, Engine

from flask_service_metrics.registry import MetricsRegistry

DEFAULT_SQL_BUCKETS: tuple[float, ...] = (0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0)

_KNOWN_OPERATIONS = frozenset(
    {"select", "insert", "update", "delete", "begin", "commit", "rollback"}
)

_START_KEY = "_flask_service_metrics_query_start"

# Защита от повторной инструментации: слушатели - замыкания, поэтому
# event.contains() их не узнает; помним сами, на что уже подписались.
_instrumented: weakref.WeakSet[Engine | type[Engine]] = weakref.WeakSet()


def _operation(statement: str) -> str:
    """Ключевое слово операции вместо текста запроса - ограниченная кардинальность."""
    parts = statement.lstrip().split(None, 1)
    keyword = parts[0].lower() if parts else "other"
    return keyword if keyword in _KNOWN_OPERATIONS else "other"


def instrument_sqlalchemy(
    registry: MetricsRegistry,
    target: Engine | type[Engine] | None = None,
    buckets: Sequence[float] | None = None,
) -> None:
    """Вешает слушатели курсорных событий на engine или на класс Engine.

    По умолчанию слушается класс Engine целиком: Flask-SQLAlchemy 3.x создаёт
    engine лениво, и на момент init_app конкретного engine ещё нет.
    """
    listen_target: Engine | type[Engine] = target if target is not None else Engine
    if listen_target in _instrumented:
        return
    _instrumented.add(listen_target)

    duration = registry.histogram(
        "sql_query_duration_seconds",
        "Время выполнения SQL-запросов, секунды",
        labelnames=("operation",),
        buckets=buckets if buckets is not None else DEFAULT_SQL_BUCKETS,
    )
    queries = registry.counter(
        "sql_queries_total",
        "Число выполненных SQL-запросов",
        labelnames=("operation",),
    )
    errors = registry.counter(
        "sql_query_errors_total",
        "Число SQL-запросов, завершившихся ошибкой",
        labelnames=("operation",),
    )

    def before_cursor_execute(
        conn: Connection,
        cursor: Any,
        statement: str,
        parameters: Any,
        context: Any,
        executemany: bool,
    ) -> None:
        conn.info.setdefault(_START_KEY, []).append(time.perf_counter())

    def after_cursor_execute(
        conn: Connection,
        cursor: Any,
        statement: str,
        parameters: Any,
        context: Any,
        executemany: bool,
    ) -> None:
        starts = conn.info.get(_START_KEY)
        if not starts:
            return
        elapsed = time.perf_counter() - starts.pop()
        operation = _operation(statement)
        duration.labels(operation=operation).observe(elapsed)
        queries.labels(operation=operation).inc()

    def handle_error(exception_context: Any) -> None:
        statement = exception_context.statement or ""
        errors.labels(operation=_operation(statement)).inc()
        # Начало замера уже не понадобится - снимаем, чтобы не текло.
        connection = exception_context.connection
        if connection is not None:
            starts = connection.info.get(_START_KEY)
            if starts:
                starts.pop()

    event.listen(listen_target, "before_cursor_execute", before_cursor_execute)
    event.listen(listen_target, "after_cursor_execute", after_cursor_execute)
    event.listen(listen_target, "handle_error", handle_error)
